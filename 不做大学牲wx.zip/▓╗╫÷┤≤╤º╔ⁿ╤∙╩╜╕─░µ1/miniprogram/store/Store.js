import Todo from '../models/Todo'

/**
 * Store 基类
 */
class Store {
  constructor() {

  }

  /**
   * 读取数据
   */
  read() {
  }

  /**
   * 保存数据
   */
  save() {
  }
}

export default Store