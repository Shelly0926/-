//index.js
const app = getApp()

Page({
  data: {
    height: '',
    age: '',
    weight: '',
    sex: [
      {value: 'woman', name: '女'},
      {value: 'man', name: '男'},
    ],
    BMI:'',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },



  // 获取性别信息
  sexChange(e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value)
  },

  // 获取身高信息
  getHeight(e){
    console.log('获取的身高为', e.detail.value)
    this.setData({
      height: e.detail.value
    })
  },

  //获取年龄信息
  getAge(e){
    console.log('获取的年龄为', e.detail.value)
    this.setData({
      age: e.detail.value
    })
  },

  //获取体重
  getWeight(e){
    console.log('获取的体重为', e.detail.value)
    this.setData({
      weight: e.detail.value
    })
  },

  begin: function(){
    var h=this.data.height
    var w=this.data.weight
    var app=getApp()
    var b=(w/(h/100)/(h/100)).toFixed(2)
    app.globalData.BMI = b
    wx.switchTab({  
      url: '/pages/eAs/eAs',  
    })
  },

  onLoad: function() {
    if (!wx.cloud) {
      wx.redirectTo({
        url: '../chooseLib/chooseLib',
      })
      return
    }
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              this.setData({
                avatarUrl: res.userInfo.avatarUrl,
                userInfo: res.userInfo
              })
            }
          })
        }
      }
    })
  },

  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },

  onGetUserInfo: function(e) {
  },

  onGetOpenid: function() {

  },

  doUpload: function () {

  },

  

})
