var util = require('../../utils/util.js');
var app=getApp()
// pages/eAs/eAs.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    BMI:"",
    food:[],
    remind:'',
    cal:app.globalData.totalCalories,
    requireCal:0,
    rate:0
  },

  trMeal(){
    if((cTime>0&&cTime<6)){
    }
  },

  // 进入输入食谱界面
  selectFood: function(){
    wx.navigateTo({
      url: 'eAs_0/eAs_0',
    })
  },
  //跳转至灯光调试
  setLights: function(){
    wx.navigateTo({
      url: 'eAs_1/eAs_1',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //显示当前摄入的能量
    this.setData({
      BMI:app.globalData.BMI,
    })
    var b=app.globalData.BMI
    console.log(app.globalData.BMI)
    if(app.globalData.BMI<18.5){
      this.setData({
        requireCal: 35000
      })
    }
    else if(app.globalData.BMI>=18.5&&app.globalData.BMI<=23.9){
      this.setData({
        requireCal: 30000
      })
    }
    else{
      this.setData({
        requireCal: 25000
      })
    }
    //获取当前时间
    var date = new Date();
    if(date.getHours()<6){
      this.setData({
        remind:"还不到早餐时间哦",
        food:"零食/水果"
      })
    }
    else if(date.getHours()>=6&&date.getHours()<=9){
      this.setData({
        remind:"一日之计在于晨，一顿不吃丢了魂。每天都按时吃早餐哦！",
        food:"早餐"
      })
    }
    else if(date.getHours()>9&&date.getHours()<=11){
      this.setData({
        remind:"咦，怎么还没开饭？吃点零食解解馋",
        food:"零食/水果"
      })
    }
    else if(date.getHours()>11&&date.getHours()<=14){
      this.setData({
        remind:"午饭时间到！",
        food:"午餐"
      })
    }
    else if(date.getHours()>14&&date.getHours()<=17){
      this.setData({
        remind:"刚吃完午饭又饿了？来点水果垫垫肚子叭",
        food:"零食/水果"
      })
    }
    else if(date.getHours()>17&&date.getHours()<=20){
      this.setData({
        remind:"走啊，去干饭！",
        food:"晚餐"
      })
    }
    else{
      this.setData({
        remind:"大晚上的该睡觉啦",
        food:"夜宵"
      })
    }
    //获取进度条
    if(this.data.cal>=this.data.requirecal){
      var me = this;
      var cxt = wx.createCanvasContext('canvasCircle');
      cxt.setLineWidth(5);
      cxt.setStrokeStyle('#eaeaea');
      cxt.setLineCap('round');
      cxt.beginPath();
      cxt.arc(100, 100, 48, 0, 2 * Math.PI, false);
      cxt.stroke();
      cxt.draw();
      //加载动画
      var steps = 1, startAngle = 1.5 * Math.PI, endAngle = 0, speed = 100, sec = 100;
      function drawing(s, e) {
        var context = wx.createCanvasContext('canvasRing');
        context.setLineWidth(6);
        context.setStrokeStyle('#11be0f');
        context.setLineCap('round');
        context.beginPath();
        context.arc(100, 100, 48, s, e, false);
        context.stroke();
        context.draw();
      }
      function drawLoading() {
        if (steps <100) {
          //这里用me,同步数据,渲染页面
          me.setData({
            step: steps
          })
          endAngle = steps * 2 * Math.PI / speed + startAngle;
          drawing(startAngle, endAngle);
          steps++;
          console.log(steps);
        } else {
          clearInterval(this.interval);
        }
      }
      this.interval = setInterval(drawLoading, sec);
      }
      else{
        var me = this;
        var cxt = wx.createCanvasContext('canvasCircle');
        cxt.setLineWidth(5);
        cxt.setStrokeStyle('#eaeaea');
        cxt.setLineCap('round');
        cxt.beginPath();
        cxt.arc(100, 50, 48, 0, 2 * Math.PI, false);
        cxt.stroke();
        cxt.draw();
        //加载动画
        var steps = 1, startAngle = 1.5 * Math.PI, endAngle = 0, speed = 100, sec = 100;
        function drawing(s, e) {
          var context = wx.createCanvasContext('canvasRing');
          context.setLineWidth(6);
          context.setStrokeStyle('#11be0f');
          context.setLineCap('round');
          context.beginPath();
          context.arc(100, 50, 48, s, e, false);
          context.stroke();
          context.draw();
        }
        function drawLoading() {
          if (steps <(me.data.cal/me.data.requireCal)*100) {
            //这里用me,同步数据,渲染页面
            me.setData({
              step: steps
            })
            endAngle = steps * 2 * Math.PI / speed + startAngle;
            drawing(startAngle, endAngle);
            steps++;
            console.log(steps);
          } else {
            clearInterval(this.interval);
          }
        }
        this.interval = setInterval(drawLoading, sec);
      }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})