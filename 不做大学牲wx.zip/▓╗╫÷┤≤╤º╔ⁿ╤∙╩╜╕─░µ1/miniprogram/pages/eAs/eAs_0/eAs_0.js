//eAs_0.js
var util = require("../../../utils/util");
//更改数组 第三个参数是对象
function editArr(arr,i,editCnt){
  let newArr = arr,editingObj = newArr[i];   
    for (var x in editCnt){
      editingObj[x]= editCnt[x];
    }
  return newArr;
}

//获取应用实例
var app = getApp()
Page({
  data: {    
    userInfo: {},
    curIpt:'',
    input:'',
    lists:[],
    curRange:[],
    remind:[],
    logs: [],
    content:'',
    calories:''
  },

  iptChange(e){ 
    let timeArr = util.setTimeHalf();   
    this.setData({
      curIpt:e.detail.value,
      curRange:timeArr
    })
    var that = this
    wx.request({
      url: util.TXAPI_BASE_URL + '/txapi/nutrient/', //天行数据营养成分表接口
        data: {
          key: util.TXAPI_KEY,
          word: e.detail.value,
      mode:0
        },
        success: function (res) {
          console.log(res.data)
          if (res.data.code == 200) {
            that.setData({
              calories: res.data.newslist[0].rl
            })
          } else {
            console.error('错误码：' + res.data.code + '，错误提示：' + res.data.msg + '，接口文档：https://www.tianapi.com/apiview/121')
            wx.showModal({
              title: '唔。我的小笨脑瓜记不住它的卡路里',
              calories: res.data.msg,
              showCancel: false,
              success: function (res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                }
              }
            })
          }
        },
        fail: function (err) {
          console.log(err)
        }
      })    
      
    
   },
   
  
  //事件处理函数
  onLoad: function () {
    var that = this;
    //获取之前保留在缓存里的数据
    wx.getStorage({
      key: 'getfood',
      success: function(res) {
        if(res.data){
           that.setData({
            lists:res.data
          })
        }
      } 
    })
    //获取用户信息
    app.getUserInfo(function(userInfo){
      that.setData({
        userInfo:userInfo
      })
    })
    //转发分享
      var that = this
      wx.showShareMenu({
        withShareTicket: true
      })
      wx.setNavigationBarTitle({
        title: '营养成分表',
      }) 
      
  },
//添加食物表单
  formReset(){
    this.setData({
      curIpt:'',
      curRange:[],
      calories:''
    })
  },
  formSubmit(){
    
    let cnt = this.data.curIpt,newLists = this.data.lists,i = newLists.length,calories=this.data.calories
    if (cnt){
      newLists.push({id:i,content:cnt,calories:calories});
       this.setData({
        lists:newLists,
        curIpt:''
      }) 
      var app=getApp()
      app.globalData.totalCalories = app.globalData.totalCalories+calories
      console.log(app.globalData.totalCalories)
    }   
  },
//删除食物
  toDelete(e){
    let i = e.target.dataset.id,newLists = this.data.lists;
    
    newLists.map(function(l,index){
      if (l.id == i){      
        newLists.splice(index,1);
      }
    })   
    this.setData({
        lists:newLists
    })
  },
  //保存数据
  saveData(){
    let listsArr = this.data.lists;
    wx.setStorage({
      key:'getfood',
      data:listsArr
    })
  }
  
})